name = 'tetrahedron'

parents = []
eulerpath = []
time = 0.00240111351013
poly = {0: [1, 2, 3], 1: [2, 0, 3], 2: [0, 1, 3], 3: [2, 1, 0]}
parents.append((3, None, 0, 1))
eulerpath.append(((1, 2, 2), (1, 0, 6), (0, 1, 4), (2, 1, 2), (2, 3, 6), (3, 2, 4)))
parents.append((3, None, 3, 1))
eulerpath.append(((1, 2, 2), (1, 0, 6), (0, 1, 2), (0, 2, 6), (2, 0, 2), (2, 1, 6)))
findings=2
complete = True
duplicates = False
