import importlib
present = ["tetrahedron","cube","octahedron","hexagonal_antiprism",
		   "j01", "j08", "j10", "j12", "j13", "j14", "j15", "j49", "j50", "j84"]
missing = ["icosahedron" "j16", "j17", "j51", "j86", "j87", "j88", "j89", "j90"]

for name in present:
	shape = importlib.import_module(name+"_tile")
	print(shape.name,shape.time)
	