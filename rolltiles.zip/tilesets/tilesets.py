import optparse
import math, re
from collections import deque
import sys
from os.path import sep
import numpy
"""Partie du début du code fournit
Changements : liste tous les nets des .wrl donnés dans un format utilisable
Supprime les duplicats et miroirs"""

try:
	import colorama
	colorama.init()
except:
	pass
from time import time
from copy import copy
folder = "wrlshapes"
#wrls = ["tetrahedron","cube","octahedron","hexagonal_antiprism","icosahedron"]
#wrls += ["j01","j08","j10","j12","j13","j14","j15","j16","j17","j49","j50","j51","j84","j86","j87","j88","j89","j90"]
#wrls = ["tetrahedron"]
#wrls += []
#wrls = ["j49", "j50", "j15", "j84", "hexagonal_antiprism", "j51", "j86"]
#wrls += ["j17", "j87", "j88", "icosahedron", "j89", "j90"]
extension = ".wrl"
complexity = [(4, 'tetrahedron'), (5, 'j01'), (6, 'cube'), (6, 'j12'), (8, 'j49'), 
(8, 'octahedron'), (9, 'j08'), (9, 'j14'), (10, 'j13'), (11, 'j50'), (12, 'j15'), (12, 'j84'), 
(13, 'j10'), (14, 'hexagonal_antiprism'), (14, 'j51'), (14, 'j86'), (15, 'j16'), (16, 'j17'), 
(17, 'j87'), (18, 'j88'), (20, 'icosahedron'), (21, 'j89'), (24, 'j90')]
wrls = [name for nbfaces, name in complexity]

outfolder = "tilenets"
outextension = "_tile.py"
	
#wrls = ["hexagonal_antiprism","icosahedron","j16","j17","j49","j50","j51","j84","j86","j87","j88","j89","j90"]
# implement polyhedron as a dict, each face number maps to the ccw list of its neighbors
#http://bulatov.org/polyhedra/johnson/index_vrml.html
#With real numbers on http://www.netlib.org/polyhedra/index.html
#Better named polyhedrons? http://www.geom.uiuc.edu/docs/weboogl/zoo/polyhedra.wrl.html
#Except for hexagonal antiprism https://en.wikipedia.org/wiki/Hexagonal_antiprism
#I couldn't find a version that parses so I had to edit it

def renumberpoly(poly):
    newpoly = {}
    keys = list(poly.keys())
    for i in range(len(keys)):
        newpoly[i] = [keys.index(j) for j in poly[keys[i]]]
    return newpoly
    
def laplacian(poly):
    n = len(poly)
    L = [[0]*n for i in range(n)]
    k = list(poly.keys())
    for node in poly.keys():
        neighbors = poly[node]
        nodenum = k.index(node)
        L[nodenum][nodenum] = float(len(neighbors))
        for neighbor in neighbors:
            neighnum = k.index(neighbor)
            L[nodenum][neighnum] = -1.0
    return L

polyangles = {
    3: 2,
    4: 3,
    6: 4
    }

class SpanningTrees:
    def __init__(self, poly, root, valid=True):
        self.poly = renumberpoly(poly)
        self.L = laplacian(self.poly)
        self.count = 0
        self.parent = {root:None}
        self.fringe = [(root,i) for i in self.poly[root]]
        self.valid = valid
        #eulerian tour (ET) is a ccw list of edges around the unfolding
        # where each edge is represented by the 2 faces it joins,
        # and the interior angle of the next vertex, in multiples of 30
        # i.e. 2 for triangles, 3 for squares etc
        self.euler = [(root,i,polyangles[len(self.poly[root])]) for i in self.poly[root]]
    def __iter__(self):
        return self.next()
    def next(self):
        while self.fringe:
            node, other = self.fringe.pop()
            if other in self.parent.keys(): continue
            #try with this edge in
            oldfringe = self.fringe[:] #saving for backtracking
            oldeuler = self.euler[:]
            oldL = [row[:] for row in self.L]
            maxangle = 0
            pos = [(a,b) for (a,b,c) in self.euler].index((node,other)) #finding the edge in ET we glue the new face to
            backedge = self.poly[other].index(node)
            neighbors = self.poly[other][backedge+1:] #getting all new edges of the ET in the right order
            neighbors.extend(self.poly[other][:backedge])
            angle = polyangles[len(self.poly[other])]
            self.euler = oldeuler[:pos]
            for neighbor in neighbors:
                self.euler.append((other,neighbor,angle))
            a,b,c = self.euler[-1]
            self.euler[-1] = (a,b,oldeuler[pos][2]+angle)
            maxangle = max(maxangle,oldeuler[pos][2]+angle)
            self.euler.extend(oldeuler[pos+1:])
            a,b,c = self.euler[(pos-1)%len(self.euler)]
            self.euler[(pos-1)%len(self.euler)] = (a,b,c+angle)
            maxangle = max(maxangle,c+angle)
            for i in self.poly[other]:  #add new edges to the fringe
                if not i in self.parent.keys():
                    self.fringe.append((other,i))
            self.parent[other] = node
            if (not self.valid) or maxangle < 11:
                if len(self.parent) == len(self.poly):  #we have a spanning tree
                    self.count += 1
                    yield (copy(self.parent), [(a,b,c) for a,b,c in self.euler], self.count)
                else:   #we recurse
                    for v in self.next():
                        yield v
            else:
                if len(self.parent) == len(self.poly):  #we have a spanning tree
                    self.count += 1
                else:
                    subL = [[self.L[i][j] for j in range(len(self.L[i])) if not j in self.parent.keys()]
                            for i in range(len(self.L)) if not i in self.parent.keys()]
                    self.count += numpy.linalg.det(subL)
            del self.parent[other]  #restore original state for backtracking
            self.euler = oldeuler[:]
            self.fringe = oldfringe[:]
            self.L = oldL
            #try with this edge out (implicitely)
            self.L[node][other]=0
            self.L[other][node]=0
            self.L[other][other] -= 1
            self.L[node][node] -= 1

def makepath(tile): #compute coordinates (careful: roundoff errors)
    path = [(0,0),(1,0)]
    angle = 0
    for a in tile:
        angle += a - 6
        x,y = path[-1]
        path.append((x+math.cos(angle*math.pi/6.0), y+math.sin(angle*math.pi/6.0)))
    return path[:-1]

def normpath(path):
    totx = 0.0
    toty = 0.0
    for (x,y) in path:
        totx += x
        toty += y
    return [(x-(totx/len(path)),y-(toty/len(path))) for (x,y) in path]

def pathtops(path, orig = (300,300), scale = 10, show=True): #generates postscript for a path
    ox,oy = orig
    s= "%f %f newpath moveto\n"%(path[0][0]*scale+ox,path[0][1]*scale+oy)
    for x,y in path:
        s += "%f %f lineto\n"%(ox+x*scale,oy+y*scale)
    s += "stroke\n"
    if show:
        s += "showpage\n"
    return s

def wrl2poly(filename):
	#Original unchanged
    f = open(filename, 'r')
    s = f.read()
    f.close()
    m = re.findall("coordIndex *\[([^\]]+)\]",s)
    if not len(m) == 1:
        print( "Can't read file")
        print("m=")
        for i in m:
            print(m)
        return False
    faces = re.split('-1,',m[0])
    faces = [[int(v.strip('\r\n ')) for v in re.split(',',a.strip('\r\n ,')) if v.strip('\r\n\t ')]
             for a in faces if a.strip('\r\n\t ')]
    
    for face in faces:
        if not len(face) in [3,4,6]:
            print( "Faces must be triangles, squares or hexagons!")
            print( faces)
            return False
    poly = {}
    touched = set([0])
    fringe = [0]
    while fringe:
        facenum = fringe.pop()
        #print( "face %d"%facenum)
        face = faces[facenum]
        #print( faces)
        #print (poly)
        neighbors = []
        for edge in range(len(face)):
            i = face[edge]
            j = (face*2)[edge+1]
            others = [other for other in range(len(faces))
                      if j in faces[other] and (faces[other]*2)[faces[other].index(j)+1] == i ]
            if not len(others) == 1:
                others = [other for other in range(len(faces))
                          if other != facenum and i in faces[other] and (faces[other]*2)[faces[other].index(i)+1] == j ]                
                if len(others) == 1:
                    if others[0] in touched:
                        others = []
                    else:
                        #print ("reverse %d"%others[0])
                        faces[others[0]].reverse()
            if not len(others) == 1:
                print ("Can't find an edge (%d,%d) from face %d"%(i,j,facenum))
                print( faces)
                return False
            #print( "found %d"%others[0])
            if not others[0] in touched:
                touched.add(others[0])
                fringe.append(others[0])
            neighbors.append(others[0])
        poly[facenum] = neighbors
    return poly
	

def not_duplicate(oldpaths,path,mirrors=True):
	size = len(path)
	for t in oldpaths:
		for start in range(size):
			counter = 0
			for i in range(1,size): #ignore the first orientation
				if(path[i] != t[(start+i)%size]):
					break
				counter+=1
			if(counter==size-1):
				#print("Duplicate removed: "+str(path)+"\nis a duplicate of "+str(t),"("+str(t[start:]+t[:start])+")")
				return False
	if(mirrors==True):
		for t in oldpaths:
			for start in range(size):
				counter = 0
				for i in range(1,size):
					#print(path[i],t[(start-i)%size])
					if(path[i]!=t[(start-i)%size]):
						break
					counter+=1
				if(counter==size-1):
					#print("Mirror duplicate removed: "+str(path)+"\nis a mirrored duplicate of "+str(t))
					return False
			
	#print("Accepted path:",path)
	return True
	
def order_polys():
	#[(4, 'tetrahedron'), (5, 'j01'), (6, 'cube'), (6, 'j12'), (8, 'j49'), (8, 'octahedron'), (9, 'j08'), (9, 'j14'), (10, 'j13'), (11, 'j50'), (12, 'j15'), (12, 'j84'), (13, 'j10'), (14, 'hexagonal_antiprism'), (14, 'j51'), (14, 'j86'), (15, 'j16'), (16, 'j17'), (17, 'j87'), (18, 'j88'), (20, 'icosahedron'), (21, 'j89'), (24, 'j90')]
	comparator = []
	for id,name in enumerate(wrls):
		filename = folder + "/" + name + extension
		poly = wrl2poly(filename)
		#print(filename,poly)
		print("(",len(poly),",",name,")")
		comparator.append((len(poly),name))
	comparator.sort()
	print(comparator)
	
def main():
	for id,name in enumerate(wrls):
		filename = folder + "/" + name + extension
		poly = wrl2poly(filename)
		print(filename,poly)
		tilescount = 0
		oldpaths = []
		
		newfile = open(outfolder+sep+name+outextension, "w")
		iter = SpanningTrees(poly,1)
		poly = iter.poly
		timer = time()
		newfile.write("name = '"+name+"'\n")
		newfile.write("\npoly = "+str(poly)+"\n")
		newfile.write("parents = []\n")
		newfile.write("eulerpath = []\n")
		newfile.write("time = None\n")
		newfile.write("complete = False\n")
		for parents,tile,count in iter:
			sides = [c for a,b,c in tile]
			#print("Found, checking duplicacy")
			if(not_duplicate(oldpaths,sides)):
				newfile.write("duplicates = False\n")
				oldpaths.append(sides)
				newfile.write("#id = "+str(tilescount))
				listing = [None]*len(parents)
				for key in parents:
					listing[key] = parents[key]
				newfile.write("\nparents.append("+str(tuple(listing))+")")
				newfile.write("\neulerpath.append("+str(tuple(tile))+")\n")
				tilescount += 1
				if(tilescount%2000 == 0):	
					newfile.write("time = "+str(time()-timer)+"\n")
					print("Elapsed: ",time()-timer)
		newfile.write("complete = True\n")
		newfile.write("time = "+str(time()-timer)+"\n")
		newfile.close()
		print(name,tilescount,"done")

if __name__ == '__main__': main ()
